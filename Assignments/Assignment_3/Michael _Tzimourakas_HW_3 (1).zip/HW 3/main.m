%% Title
% Michael Tzimourakas
% HW 3
%% Housekeeping
clear
close all
clc
%% Work


