function plotresults(e_i,e_q,p_i,p_q,l_i,l_q,carrierfq,codefq,handles)
axes(handles.Results_correlation)
plot(handles.Results_correlation,p_i .^2 + p_q .^ 2, 'g.-')
hold on
plot(handles.Results_correlation,e_i .^2 + e_q .^ 2, 'bx-')
plot(handles.Results_correlation,l_i .^2 + l_q .^ 2, 'r+-')
grid on
xlabel('milliseconds')
ylabel('amplitude')
title('Correlation Results')
legend('prompt','early','late')


axes(handles.Prompt_1)
plot(handles.Prompt_1,p_i)
grid on
xlabel('milliseconds')
ylabel('amplitude')
title('Prompt I Channel')

axes(handles.Prompt_Q)
plot(handles.Prompt_Q,p_q)
grid on
xlabel('milliseconds')
ylabel('amplitude')
title('Prompt I Channel')

axes(handles.Track_code_frequency)
plot(handles.Track_code_frequency,1.023e6 - codefq)
grid on
xlabel('milliseconds')
ylabel('Hz')
title('Tracked Code Frequency (Deviation from 1.023MHz)')

axes(handles.Tracked_intermediate_frequency)
plot(handles.Tracked_intermediate_frequency,carrierfq)
grid on
xlabel('milliseconds')
ylabel('Hz')
title('Tracked Intermediate Frequency')

end