function [ rho ] = density( T,P )
% Calculates density as a function of hight


rho = P/(0.2869*(T + 273.15));



end

